rosauth [![Build Status](https://api.travis-ci.org/WPI-RAIL/rosauth.png)](https://travis-ci.org/WPI-RAIL/rosauth)
=======

#### Server Side tools for Authorization and Authentication of ROS Clients
For full documentation, see [the ROS wiki](http://ros.org/wiki/rosauth).

[Doxygen](http://docs.ros.org/indigo/api/rosauth/html/) files can be found on the ROS wiki.

### License
rosauth is released with a BSD license. For full terms and conditions, see the [LICENSE](LICENSE) file.

### Authors
See the [AUTHORS](AUTHORS.md) file for a full list of contributors.
