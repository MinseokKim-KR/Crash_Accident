# Setup HOST

## One-time setup

You need to run the `setup_host.sh` at least once for a new HOST environment.
